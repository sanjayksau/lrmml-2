addpath(genpath('.'));
clear all;
fprintf('*** Begin LRMML ***\n');
%1 - lambda naming convention might be different from the one used in LRMML Paper.
%2 - Run Grid Search for finding optimal hyperparameters for best results.
    lambda   = 10^-1; 
    lambda1   = 2^1; 
    lambda2   = 10^-1; 
cv_num             = 5;
datasets={'medical.mat'};
alpha=1; %W initializtion
misRate = 0.3;
load('medical.mat');
if exist('train_data','var')==1
    data    = [train_data;test_data];
    target  = [train_target,test_target];
end
clear train_data test_data train_target test_target
target(target == 0) = -1;
data      = double (data);
num_data  = size(data,1);
temp_data = data + eps;
temp_data = temp_data./repmat(sqrt(sum(temp_data.^2,2)),1,size(temp_data,2));
if sum(sum(isnan(temp_data)))>0
    temp_data = data+eps;
    temp_data = temp_data./repmat(sqrt(sum(temp_data.^2,2)),1,size(temp_data,2));
end
temp_data = [temp_data,ones(num_data,1)];

rng(42);
randorder = randperm(num_data);
cvResult  = zeros(2,cv_num);
for j = 1:cv_num
    fprintf('- Cross Validation - %d/%d', j, cv_num);
    [cv_train_data,cv_train_target,cv_test_data,cv_test_target ] = generateCVSet( temp_data,target',randorder,j,cv_num );
    temptarget = cv_train_target;
    IncompleteTarget= getIncompleteTarget(cv_train_target, misRate); 
    modelLRMML = LRMML(cv_train_data, IncompleteTarget, lambda, lambda1, lambda2, alpha);
    Outputs = (cv_test_data*modelLRMML)';
    Pre_Labels = sign(Outputs);
    tmpResult(1, 1)    = Hamming_loss(Pre_Labels,cv_test_target');
    tmpResult(2, 1)   = Average_precision(Outputs,cv_test_target');
    cvResult(:,j) = cvResult(:,j) + tmpResult;
end
Avg_Result      = zeros(2,2);
Avg_Result(:,1) = mean(cvResult,2);
Avg_Result(:,2) = std(cvResult,1,2);
fprintf('\nEvaluation Metric    Mean    Std\n');
fprintf('------------------------------------\n');
fprintf('HammingLoss           %.4f  %.4f\r',Avg_Result(1,1),Avg_Result(1,2));
fprintf('Averge Prec           %.4f  %.4f\r',Avg_Result(2,1),Avg_Result(2,2));
fprintf('------------------------------------\n');
