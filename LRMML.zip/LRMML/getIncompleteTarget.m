function [target]= getIncompleteTarget(target, percent)
% delete the elements in the target matrix 'oldtarget' by the given percent
obsTarget_index = ones(size(target));

%totalNum = numel(target); %better and shorter if both pos and neg are considered for incompletion: sanjay
totalNum = sum(sum(target ==1));
totalNum = totalNum + sum(sum(target == -1));
totaldeleteNum = 0;
[N,~] = size(target);
realpercent = 0;
maxIteration = 50;
factor = 2;
count=0;
while realpercent < percent
    if maxIteration == 0
        factor = 1;
        maxIteration = 10;
        if count==1
            break;
        end
        count = count+1;
    else
        maxIteration = maxIteration - 1;
    end
    for i=1:N
        %index = find(target(i,:)==1);
        index = find(target(i,:)==1 | target(i,:)==-1); 
        if length(index) >= factor % can be set to be 1 if the real missing rate can not reach the pre-set value
            deleteNum = round(1 + rand*(length(index)-1));
            totaldeleteNum = totaldeleteNum + deleteNum;
            realpercent = totaldeleteNum/totalNum;
            if realpercent >= percent
                break;
            end
            if deleteNum > 0
                index = index(randperm(length(index)));
                target(i,index(1:deleteNum)) = 0; %key step, convert known(-1,1) to unknown (0)
                obsTarget_index(i,index(1:deleteNum))=0;
            end
        end
    end
end
end