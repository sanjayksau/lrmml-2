function[Wtplus]=LRMML(Xtrain, Ytrain, lambda, lambda1, lambda2, alpha)
[n, m]=size(Ytrain);
[~, d]=size(Xtrain);
X=cell(m, 1);
for i=1:m
    tempindex=find(Ytrain(:, i)>0);
    X{i}=Xtrain(tempindex, :);    
end
J = Ytrain ~= 0;
%alpha = 2^0;
XTX = Xtrain' * Xtrain;
XTY = Xtrain' * Ytrain;
num_dim = d;
Wt = (XTX + alpha*eye(num_dim)) \ (XTY); %zeros(num_dim,num_class); % 
Rt = eye(m, m); %start with sparse correlation
%Rt=zeros(m, m); % eye(m, m);
Flag=true;
iteration=1;
while Flag && iteration <25
    [Wtplus, Rtplus]=optsurrogate(Xtrain, X, Ytrain, J, Wt, Rt, lambda, lambda1, lambda2);
    if norm(Wtplus-Wt, 'fro')/norm(Wt, 'fro') <10^-3
        Flag=false;
    else
       iteration=iteration+1; 
       Wt=Wtplus;
       Rt=Rtplus;
    end    
end
end

